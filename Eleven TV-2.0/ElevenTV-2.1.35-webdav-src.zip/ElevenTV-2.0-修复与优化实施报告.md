# ElevenTV 2.0 审查缺陷修复与性能优化 · 实施报告

依据 `ElevenTV-2.0-源码审查报告.md` 的 33 条发现逐条处置。

## 约束与基线

| 项 | 说明 |
|---|---|
| 功能 / 接口行为 / 兼容性 | 保持；未改 `ElevenRepository`、`RemoteStorage`、`SmbServer` 等任何公开接口与数据模型字段 |
| 改动范围 | 仅审查报告点名的 12 个 Kotlin 源文件 + 1 个已有测试文件；未改 `build.gradle.kts`、未改 `libs.versions.toml`、未改 UI 页面 |
| 依赖 | **零新增**。`implementation(libs.okhttp)`（4.12.0）本就在 `app/build.gradle.kts` 中声明，`data/scrape/Http.kt` 一直在用；PERF-01 只是把 WebDAV 传输层改用这项既有依赖 |
| 基线 | 改动前 `:app:compileDebugKotlin` BUILD SUCCESSFUL（58s，4 条既有 warning）；原始源码备份于 `.baseline-java/` |

## 验证环境与方法

- JDK：Android Studio 自带 JBR 25.0.4；Gradle 9.6.0 / Kotlin 2.3.21；`ANDROID_HOME` 指向 SDK（android-36）；全程 `--offline`，依赖均来自本地缓存。
- 每批次改动后各做一次增量编译，把错误锁死在批次内；最后做完整编译、全量单测与 APK 打包。
- 静态核验：改动前后 import 集合对比、`!!`/`GlobalScope`/`runBlocking` 否决项扫描、调用点线程核对、diff 行数与文件清单统计。
- **诚实边界**：本机没有 NAS / Android TV 真机，端到端耗时、崩溃、OOM、屏保、Keystore 重置等场景无法实测；报告中对这些条目给出可复现的真机回归步骤，不把「编译通过」冒充「线上已验证」。

## 总体验证结果

| 验证项 | 结果 |
|---|---|
| 基线编译（改动前） | BUILD SUCCESSFUL，4 条既有 warning |
| 4 个批次增量编译 | 全部 BUILD SUCCESSFUL |
| `:app:compileDebugKotlin`（最终） | BUILD SUCCESSFUL，无新增告警（新引入的 `Cast is redundant` 已消除；编译期仅剩基线原有的 3 条 `SmbDataSource` + 1 条 `SplashSound` 告警） |
| `:app:testDebugUnitTest` | **62 / 62 通过，failures=0 errors=0 skipped=0**（原 61 条 + 新增 1 条连接复用断言 + 1 条 `Connection: close` 断言） |
| `:app:assembleDebug` | BUILD SUCCESSFUL，产出 `app-debug.apk` 20 MB |
| 新增依赖 | 0；新增 import 仅 okhttp3（既有依赖）、JDK 网络异常类、kotlinx.coroutines（既有依赖） |
| 一票否决项 | 未新增 `!!`、`GlobalScope`、`runBlocking`；新增 1 处 `Thread.sleep` 已核实全部调用点在 `Dispatchers.IO` |

---

## 一、潜在 Bug（12 条）

### BUG-01【高】播完后重播，ticker 不再恢复
- **修复内容**：`PlayerState` 新增 `ensureTicker()`（`removeCallbacks` + `post`），`init`、`start()`、`togglePlayPause()` 的 `STATE_ENDED` 分支统一调用。`STATE_ENDED` 里摘掉 ticker 以停止空转的逻辑保留，但重播路径现在会挂回。
- **影响范围**：播放器 OSD 生命周期、进度同步、每 5 秒落盘、12 秒取流超时提示；涉及「电影/单集播完按 OK 重播」与「关闭自动连播」两条路径。正常起播、换集、切解码器行为不变。
- **验证结果**：编译 + 62 单测通过；静态核验 ticker 的三个挂载点、一个摘除点无遗漏。**待真机**：播完电影按 OK 重播，看进度条是否走动、`playback.json` 的 `positionMs` 是否刷新、卡住时是否仍弹超时提示。

### BUG-02【高】目录深度超 8 层被静默跳过
- **修复内容**：`Scanner.walk()` 的 `if (depth > MAX_DEPTH) return 0` 改为 `Log.w(...) ; return 1`，计入 `failedDirs`。
- **影响范围**：`ScanResult.failedDirs`、`LocalRepository.scan()` 的零结果保护与失败目录增量合并、任务栏文案。超深目录由「静默跳过并整表覆盖」变为「计入失败并保留上次条目」。
- **验证结果**：编译 + 单测（`FilenameParserTest` 23 条）通过。**待真机**：构造 10 层嵌套目录、最深层放 1 个 mkv，确认 `failedDirs>0`、旧库条目未被清空、UI 出现不完整提示。

### BUG-03【高】并入无年份文件时未同步集号集合
- **修复内容**：`Scanner.splitByIdentity()` 把 `unknown` 并入最大簇时，同步执行 `cluster.eps.addAll(epKeys(unknown))`。
- **影响范围**：同名剧归并、详情页季/集分组、`stableId`。仅影响「同名 + 带年份与不带年份文件混合」的库。
- **验证结果**：编译 + 单测通过；静态核验 `epKeys` 后向引用合法。**待真机**：两部同名不同年份剧 + 一批无年份分集，断言拆成 2 个条目。

### BUG-04【中】stableId 漂移 —— **有意不做**
- **处置与理由**：不改 id 生成规则。任何改动都会让已有 `library.json` / `playback.json` 里的 id 集体变化，直接违反「兼容性不变」；现有 `inheritScrape`（按 `fileId` 继承刮削）与 `remapPlayback`（按 `fileId` 重挂记录）已兜住主要数据；BUG-03 的修复消除了「eps 偏小导致误合并」这一主要翻转来源。
- **影响范围**：无代码改动。
- **验证结果**：diff 确认 `groupEntries` 的 `idKey` 与 `stableId` 逻辑逐字未变。
- **后续建议**：若要做，必须配套 `oldId → newId` 映射与数据迁移，单独排期，不能混在本次修复里。

### BUG-05【中高】WebDAV `isSelf` 判定失败导致目录递归进自己
- **修复内容**：`WebDavStorage.parse()` 增加 `selfRawPath`，用「解码路径相等」或「rawPath 相等」双重判定；`Scanner.walk()` 增加 `visited` 集合防环，且 **按每个 root 单独新建**（两个根存在包含关系时后一个根仍按自己的 `kindOverride` 走一遍，避免丢类型覆写）。
- **影响范围**：WebDAV 目录解析与扫描遍历；正常服务器遍历顺序不变，仅在 href 编码异常时不再产生重复条目。
- **验证结果**：编译 + `DavHttpTest` 4 条通过；静态核验 `visited` 在 `for (root ...)` 内创建。**待真机**：中文/空格目录 + 返回绝对编码 href 的 NAS，检查是否出现重复层级。

### BUG-06【中】备份恢复用非原子 `copyTo` 回写
- **修复内容**：`JsonStore.restoreFromBackup()` 去掉 `bak.copyTo(file, overwrite=true)`，改走 `write(serializer, value)`（tmp + `fd.sync()` + `ATOMIC_MOVE`）；通过 `deserializer as? SerializationStrategy<T>` 复用 KSerializer 的双向能力。`read()` 与 `write()` 持有同一把可重入锁，不会死锁。
- **影响范围**：仅「主文件损坏 → 从备份恢复」路径；正常 `read` / `write` 不变。
- **验证结果**：编译 + 单测通过；静态核验锁可重入、非 KSerializer 场景有降级日志。**待真机**：人为截断 `library.json` 后启动，确认主文件是完整 JSON 且 `.bak` 未被破坏。

### BUG-07【中高】Keystore 重置后空密码回写覆盖原密文
- **修复内容**：`SecretBox` 新增 `tryOpen()`（失败返回 `null`），`open()` 保持旧行为兼容；`LocalRepository` 增加 `passwordNeedsRefill` 集合，`init()` 解不开时保留原始密文并登记，`persistServers()` 对该类条目原样写回、不做二次 seal，`saveServer()` / `deleteServer()` 清理标记；加密降级日志明确写出「密码将以明文写入」。
- **影响范围**：`servers.json` 落盘、服务器编辑/删除流程；正常路径无变化。**UI 状态提示未加**（见「部分处理项」）。
- **验证结果**：编译 + 单测通过；静态核验 `seal("")` 不会再被写盘。**待真机**：清除应用 AndroidKeyStore 条目后重启并触发一次「保存服务器」，确认 `password` 仍带 `enc1:` 前缀。

### BUG-08【中高】无容器时长片源永不保存进度
- **修复内容**：`PlayerState.saveProgress()` 在 `player.duration == TIME_UNSET` 时以 `duration = 0` 继续落盘；`LocalRepository.saveProgress()` 放宽 duration 校验，并在 `duration<=0` 时不做 `coerceAtMost(duration)`，避免把位置压成 0。
- **影响范围**：TS / m2ts / 部分 ISO 的续播与「继续播放」行；`PlaybackRecord.progress` 仍按 0 时长返回 `0f`、`finished=false`，进度条比例不显示（无时长本就无法显示比例）。
- **验证结果**：编译 + 单测通过；静态核验 `Models.PlaybackRecord` 的 `progress/finished` 已按 `duration<=0` 兜底。**待真机**：播放无 duration 的 `.ts` 5 分钟后退出，检查 `playback.json` 有记录且再次进入能续播。

### BUG-09【中】`fileId` 失效时静默回退第一集
- **修复内容**：`PlayerActivity` 区分 `requestedFile` 与 `primaryFile` fallback，失效时 Toast「该集已变更，将播放默认集」。
- **影响范围**：仅多一条提示，播放行为不变。
- **验证结果**：编译 + 单测通过。**待真机**：重扫改名后从「继续播放」进入，确认有提示。

### BUG-10【中】自动重试的 1 秒延迟任务打断用户换集
- **修复内容**：新增 `playGeneration`，`start()` 递增；`onPlayerError` 的延迟任务捕获当前代际，执行前比对 `generation == playGeneration` 才 `retry()`。
- **影响范围**：仅可恢复取流失败后的自动重试路径；正常播放不变。
- **验证结果**：编译 + 单测通过。**待真机**：注入一次 IO 失败后立刻按选集换片，确认不被拉回。

### BUG-11【中】PROPFIND 的 303 沿用原方法
- **修复内容**：`WebDavStorage` 的 `REDIRECTS` 移除 303，`when(response.code)` 新增 303 明确文案（要求改用 GET，不再继续跟随）。301/302/307/308 手动跳转逻辑保持。
- **影响范围**：仅返回 303 的服务器；其余状态码行为不变。
- **验证结果**：编译 + `DavHttpTest` 通过。**待真机**：302 补斜杠服务，确认 `davNotFoundHint()` 结论准确。

### BUG-12【低】`PlayerState.seekTo(ms)` 死代码
- **修复内容**：删除该私有方法（全仓无调用点；内部 `coerceIn(0, durationMs)` 还藏着「起播瞬间 duration=0 把目标压成 0」的隐患）。
- **影响范围**：无（private 且无引用）。
- **验证结果**：Python 全仓检索 `seekTo(` 调用点确认；编译通过。后续若要给进度条加拖拽，必须复用 `seekBy` 的时长兜底逻辑。

---

## 二、性能瓶颈（9 条）

### PERF-01【高】WebDAV 每目录新建 TCP 连接（主瓶颈）
- **优化内容**：`DavHttp` 传输层改用项目**已声明**的 okhttp3 4.12.0 —— 单一 `ConnectionPool`，`baseClient.newBuilder()` 共享连接池、只覆盖本次超时，连续 PROPFIND 复用同一条连接。为守住「接口行为不变」，做了四件事：① `exchange()` 签名、`DavResponse` 结构、响应头名小写约定原样保留；② `followRedirects(false)` / `followSslRedirects(false)` / `retryOnConnectionFailure(false)`，跳转仍由 `WebDavStorage.request` 手动跟、重试仍由 `WebDavStorage.list` 按 `retryable` 判定；③ 显式 `Accept-Encoding: identity`，避免 OkHttp 自动 gzip 悄悄改变响应体语义；④ `unwrap()` 把包在 cause 链里的 `SSLHandshakeException` / `SocketTimeoutException` / `ConnectException` / `UnknownHostException` 解包后原样抛出，保证原有精确排障文案继续命中。
- **量化收益**：`DavHttp.kt` 213 → 124 行（**-89 行，-42%**）；N 个目录由 N 次 TCP 握手（HTTPS 再加 N 次 TLS 握手）降为 1 次 + 复用；逐字节 `readLine`、chunked / EOF 三套手写解析与中间拷贝全部移除（同时覆盖 PERF-07、RISK-02）。
- **影响范围**：全部 WebDAV PROPFIND（扫描、目录浏览、测试连接、大小写探测、404 诊断）；SMB 路径完全不受影响。
- **验证结果**：**新增单测「连续 PROPFIND 复用同一条 TCP 连接」通过** —— 假服务器只 `accept()` 一次、在同一 socket 应答两次，断言 `accepts == 1`；另加「请求头不含 `Connection: close`」断言；原 3 条 `DavHttpTest`（请求行/头、chunked、204 空体）全过；62/62 单测 + 完整 APK 构建通过。**端到端扫描计时需真机 NAS，本机无 NAS 未实测**，报告第六节给出抓包测量方法。
- **回归重点**：自签证书 HTTPS、401/403/404/405、302 补斜杠、chunked 响应、几千集大目录 PROPFIND。

### PERF-02【高】`scan()` 在循环内线性扫描整个旧库
- **优化内容**：`LocalRepository.scan()` 预建 `previousById = previous.associateBy { it.id }` 取代 `previous.firstOrNull { ... }`；失败目录合并处预建 `freshIds` 取代 `fresh.none { it.id == old.id }`。
- **量化收益**：复杂度由 **O(F×P)** 降为 O(F+P)；2000 条旧库约省去 400 万次字符串比较。
- **影响范围**：`scan()` 的刮削结果继承与失败目录增量合并；结果集合完全等价（索引查找等价于线性查找命中项）。
- **验证结果**：编译 + 62 单测通过。**待真机**：2000 条旧库重扫计时 / Profiler 对比。

### PERF-03【中高】`homeRows()` 6 次全表扫描 + 排序
- **优化内容**：一次遍历按 `effectiveKind` 分桶（只收 `HOME_KINDS` 内的类型），再对各桶 `sortedByDescending(addedAt).take(16)`；`continueItems` 逻辑不变。
- **量化收益**：全表扫描 6 → 1 次；全表排序由 6 次降为「只对组内排序」，比较量约降至 1/5。
- **影响范围**：首页 6 行的内容、顺序、每组 16 条上限全部不变（`HOME_KINDS` 遍历顺序未改）。**派生字段缓存（改 `Models.LibraryEntry` 加字段）未做**，理由见部分处理项。
- **验证结果**：编译 + 62 单测通过；静态核验 `HOME_KINDS` 顺序与 `take(16)` 未变。**待真机**：5000 条库、后台刮削+播放并发时 Macrobenchmark 测首页帧率。

### PERF-04【中】每 5 条刮削结果全量序列化 + fsync
- **优化内容**：批量阈值由字面量 `5` 提为常量 `SAVE_BATCH = 20`；`awaitAll()` 之后的无条件 `mergeAndSave(merged)` 兜底写保留。
- **量化收益**：1000 条刮削由 **200 次**整库序列化+fsync+原子替换降为约 **50 次**（含最后兜底写）。
- **影响范围**：刮削期间 UI 增量刷新频率降低；功能与最终落盘结果不变（有兜底写，不会丢最后不足一批的结果）。
- **验证结果**：编译 + 62 单测通过；静态核验兜底写仍在 `awaitAll()` 之后。

### PERF-05【中】单条刮削串行发起十余次网络请求
- **优化内容**：`Scraper.enrich()` 用 `coroutineScope` + 两个 `async(Dispatchers.IO)` 并行发起豆瓣与 fanart，再按原顺序合并结果；每个源仍各自 `runCatching` 吞异常。
- **量化收益**：两源都需补充时，耗时由 `T_douban + T_fanart` 降为 `max(T_douban, T_fanart)`。
- **影响范围**：`ScrapeResult` 字段填充结果等价；失败降级路径不变。**TMDB 结果缓存与全局 401/429 短路未做**（会改变数据新鲜度与接口行为，见部分处理项）。
- **验证结果**：编译 + 62 单测通过；静态核验 `result.rating` / `backdropUrl` 合并顺序与原实现一致。**待真机**：整库刮削总耗时、429 限流下的收敛速度对比。

### PERF-06【中】扫描归并多次全表遍历
- **优化内容**：`Scanner.buildEntry()` 三次 `groupingBy().eachCount()` 合并为**一次遍历** + 三个 `LinkedHashMap` 投票表（用 `LinkedHashMap` 而非 `HashMap` 是为了保持平票时 `maxByOrNull` 的取值与 `groupingBy` 完全一致）；`splitByIdentity` 的 `eps.intersect(...).isEmpty()` 改为 `eps.none { it in other.eps }`，去掉每次簇比较新建的临时 Set。
- **量化收益**：每 bucket 全量遍历 3 → 1 次；消除簇两两比较时的 O(k²) 次短命 Set 分配。**并查集重写未做** —— k（年份簇数）通常很小，改动合并语义的风险大于收益。
- **影响范围**：`kind` / `year` / `title` 的多数票结果与同名剧拆分结果不变。
- **验证结果**：编译 + `FilenameParserTest` 23 条全过。

### PERF-07【中】`DavHttp.readLine` 逐字节读头部
- **优化内容**：随 PERF-01 的 OkHttp 替换整体移除，状态行 / 头 / chunked / EOF 边界交由成熟网络栈处理；顺带修正了旧注释「不值得再包一层缓冲区」与调用方已 `buffered()` 的矛盾。
- **量化收益**：删除约 100 行手写解析，单请求不再有「每字节一次方法调用 + StringBuilder 追加 + 长度检查」。
- **影响范围**：同 PERF-01。
- **验证结果**：`DavHttpTest` 的 chunked 分块拼接、204 无响应体、Content-Length 三态用例全过（4/4）。

### PERF-08【低】`onCues` 无条件赋新列表
- **优化内容**：`PlayerState.onCues()` 改为 `if (texts != cues) cues = texts`，与已有的 `bitmapCues` 判断对称。
- **量化收益**：字幕内容不变的帧不再触发字幕层重组。
- **影响范围**：仅字幕 Composable 的重组次数。
- **验证结果**：编译 + 62 单测通过。**待真机**：Layout Inspector 统计连续字幕帧下的重组次数。

### PERF-09【中】目录遍历完全串行 —— **有意不做**
- **处置与理由**：并发会改变 DFS 遍历顺序、`onProgress` 计数语义与 `onFile` 回调时序（现为单线程，`counter[0]`、`raw` 均非线程安全）；SMB 连接池容量与 NAS 并发承受力需真机压测才能定并发度；而 PERF-01 已覆盖扫描链路的主要瓶颈收益。按「重构收益必须大于风险」「拒绝范围蔓延」，本次不引入并发。
- **影响范围**：无代码改动。
- **验证结果**：diff 确认 `walk()` 仍为串行 DFS。
- **后续建议**：若要落地，先把 `onFile` 回调改为线程安全累加，再用 `Semaphore` 限流并做 NAS 端 `STATUS_TOO_MANY_SESSIONS` 压测。

---

## 三、风险与边界（12 条）

### RISK-01【高】`SmbPool.closeAll()` 不持锁、不查 `busy()`
- **修复内容**：按 `lockOf(key)` 持锁逐个 `retire`；`busy()`（有 `openHandles` 或 `activeOps`）的连接只标记 `retired` 并放进 `zombies` 延迟关闭，空闲的才立即 `close()`；最后再对 zombies 做一次 `closeIfIdle`。
- **影响范围**：退出应用 / 删除服务器时的连接回收；不再打断进行中的扫描或播放。其余 `retire` / `sweep` / `with` 逻辑未动。
- **验证结果**：编译 + 62 单测通过；静态核验 `slots.remove(key, slot)` 为原子条件删除。**待真机**：扫描进行中退出应用，观察异常率与条目完整性。

### RISK-02【高】单次 PROPFIND 响应体 32MB 且存在双份拷贝
- **优化内容**：`DavHttp.MAX_BODY_BYTES` 32MB → **16MB**；移除 `readChunked` / `readUntilEof` 的 `ByteArrayOutputStream → toByteArray()` 双份路径与 chunk 上限的 Int 溢出隐患，改由 OkHttp 完成后一次 `resp.body.bytes()` 取出并做上限检查。
- **量化收益**：单次分配上限与峰值内存各降 50%（32MB×2 → 16MB×2），且超限时明确报「响应体过大」而不是 OOM。
- **影响范围**：超大目录 PROPFIND；正常响应不受影响。
- **验证结果**：`DavHttpTest` chunked 用例通过；62/62 单测 + APK 构建通过。**待真机**：低内存盒子 + 30MB 响应，观察 PSS 峰值与 OOM。

### RISK-03【中】WebDAV 凭据 HTTP+Basic 明文传输 / 错误文案带完整 URL —— **部分处理**
- **修复内容**：新增 `String.safeForLog()`，`request()` 内所有报错文案统一只保留 `scheme://host:port/path`，去掉可能带 token 的 query；`where` 与两处异常文案全部改用脱敏 URL。
- **未做**：设置页的「HTTP + Basic」风险警示。理由：那是产品交互/文案改动，需要改 UI 页面，超出本次「代码层修复、接口行为不变」的范围；且改动会新增用户可见提示，属于行为变化。
- **影响范围**：错误文案内容；凭据传输方式与默认 `tls=false` 保持不变（不改默认值是为了兼容性）。
- **验证结果**：编译 + 62 单测通过；静态核验 `请求 $url` 已无残留、`safeForLog()` 所有引用均在 `request()` 作用域内。

### RISK-04【中】Keystore 不可用时加密静默退化为明文 —— **部分处理**
- **修复内容**：`SecretBox.seal()` 失败分支日志升级为明确写出「密码将以【明文】写入 servers.json（需提示用户）」；配合 BUG-07 的 `passwordNeedsRefill` 保留原密文，避免降级路径再叠加数据丢失。
- **未做**：设置页状态提示（同 RISK-03）。
- **影响范围**：仅日志内容；`seal()` 返回值与「没有可用 Keystore 也不能让人登不上 NAS」的兼容策略完全不变。
- **验证结果**：编译 + 62 单测通过。

### RISK-05【中】「零结果保护」在首次扫描时不生效
- **修复内容**：`LocalRepository.scan()` 的 `if (fresh.isEmpty() && previous.isNotEmpty())` 改为 `if (fresh.isEmpty())`，文案按「有无旧库」分别说明，始终返回 `JobStatus.Failed` 且不写空库。
- **影响范围**：首次配置且 NAS 不可达时，状态由 `Done（0 部）` 变为 `Failed` 并保留现状；正常扫描不变。
- **验证结果**：编译 + 62 单测通过。**待真机**：配置好服务器后断开网络冷启动，确认任务栏报错且库未被写空。

### RISK-06【中】删除服务器裁剪媒体库前没有备份
- **修复内容**：`deleteServer()` 在裁剪前执行 `libraryStore.backup()` 与 `playbackStore.backup()`（与 `scan()` 一致），并清理 `passwordNeedsRefill` 中的该 id。
- **影响范围**：删除服务器的落盘流程；裁剪逻辑本身未变。
- **验证结果**：编译 + 62 单测通过。**待真机**：删除一台服务器后检查两个 `.bak` 的时间戳与内容可恢复性。

### RISK-07【中】「数字文件名＝分集」启发式因多版本而漏判
- **修复内容**：`Scanner.numericEpisodeDirs()` 的 `MutableSet<Int>` 改为 `MutableList<Int>` 计数，判据允许「同一集的多版本」也凑够文件数；同步更新注释，说明 `01.mkv` 与 `1.mkv` 归一化后同集导致去重丢信号的问题。
- **影响范围**：分集目录识别；`01.mkv + 1.mkv` 这类多版本目录现在会被正确识别（原本漏判）。已在注释中承认的「电影合集误判」取舍不变。
- **验证结果**：编译 + `FilenameParserTest` 23 条全过。**待真机**：多版本目录扫描，检查形态与 id 是否稳定。

### RISK-08【中】未知文件长度时一次 0 字节读取就判 EOF
- **修复内容**：`SmbDataSource.read()` 增加 `zeroReadStreak`，长度未知（`bytesRemaining == Long.MAX_VALUE`）时连续 2 次读到 0 字节才 `eof()`，中间给一次 `reattach()` 就地重连；已知长度分支与异常分支的 `RECOVER_ATTEMPTS` 判定保持原样。
- **影响范围**：NAS 拒绝 `FILE_STANDARD_INFORMATION` 的片源 EOF 判定；真实结束时最多多一次重连（局域网几十~几百 ms）。不再把网络抖动误报成播放结束、触发跳集。
- **验证结果**：编译 + 62 单测通过。**待真机**：模拟 SMB 连接静默断开但保持长度未知，观察是否仍跳到下一集。

### RISK-09【中】`SmbIoStats` 全局单例统计串台 —— **部分处理**
- **修复内容**：新增 `@Synchronized` 的 `addRead / incOpen / addOpenCost / incReconnect / noteFirstRead`，消除 `@Volatile` 字段上 `+=` / `++` 的读-改-写丢计数；与 `reset()` 共用同一把对象锁。**所有对外字段类型与 `PlayerState` 的读取方式保持不变**（接口兼容）。
- **未做**：sessionId 隔离。理由：需要把 `SmbIoStats` 改成按实例注入，会改变公开接口，违反「接口行为不变」。
- **影响范围**：仅统计数值的准确性；播放主流程不变。
- **验证结果**：编译 + 62 单测通过；静态核验所有 `bytesRead +=` / `readCalls++` 等调用点已替换、无残留。

### RISK-10【中】WebDAV 重试无退避、目录失败跳过整棵子树 —— **部分处理**
- **修复内容**：`WebDavStorage.list()` 重试前 `Thread.sleep(RETRY_BACKOFF_MS = 400)`，避免两次请求撞进 NAS 同一个过载窗口；常量与注释说明这是同步 `RemoteStorage.list` 接口约束下的取舍（若日后改为 `suspend`，应换成 `delay()`）。
- **未做**：收集失败路径清单并在任务栏展示 —— 需要改 `ScanResult` 接口与任务栏 UI，超出本次范围；现有 `LocalRepository.scan()` 的增量合并兜底已保留。
- **影响范围**：仅「retryable 失败后的第二次请求」时序；**已核实**全部 `WebDavStorage` / `davRepairCase` / `davNotFoundHint` 调用点都在 `withContext(Dispatchers.IO)` 内，不会阻塞主线程。
- **验证结果**：编译 + 62 单测通过；静态核验调用点线程。

### RISK-11【低】DoH 投毒识别依赖硬编码段、跳过 IPv6 —— **有意不做**
- **处置与理由**：IPv6 投毒样本与「段表可下发配置」都缺实测依据，硬编码新段是猜测，引入配置机制又会新增接口；且把 `failureUntil` 提到 `cache` 之前会丢掉有效缓存、得不偿失。按「不确定就说不确定」，本次只补注释明确两处是**有意设计**：IPv6 放行是「无样本不猜测」、缓存命中优先于熔断是「不该因一次失败丢掉刚验证过的干净应答」。掩码计算已逐位复核无误，不改动。
- **影响范围**：无逻辑改动（仅注释）。
- **验证结果**：diff 确认 `isPoisoned` / `DohDns.lookup` 逻辑逐字未变。

### RISK-12【中】屏保心跳在 API 33+ 实际不生效 —— **有意不做**
- **处置与理由**：`PowerManager.userActivity(long, boolean)` 在 API 33+ 已从 android.jar 移除，反射兜底是现有实现能做到的最安全降级；在无真机回归前猜测其它系统私有 API 属于引入未提及的技术，且可能破坏兼容性。本次补注释写明**兼容边界**（API 33+ 只剩 `FLAG_KEEP_SCREEN_ON`）与具体回归步骤。
- **影响范围**：无逻辑改动（仅注释）。
- **验证结果**：diff 确认 `pokeUserActivity` / `userActivityMethod` / `startScreenGuard` 逻辑未变。
- **待真机**：分别在 Android 9 与 Android 13+ 盒子静置超过系统屏保时间，确认是否被屏保覆盖，再决定是否另做适配。

---

## 四、改动清单

### 生产代码（12 个文件，均在审查报告点名范围内）

| 文件 | 行数变化 | 主要处置 |
|---|---|---|
| `data/scan/Scanner.kt` | 436 → 474 | BUG-02 / BUG-03 / BUG-05 防环、RISK-07、PERF-06 |
| `data/repo/LocalRepository.kt` | 748 → 799 | PERF-02 / 03 / 04、RISK-05 / 06、BUG-07 / 08 |
| `data/store/JsonStore.kt` | 161 → 172 | BUG-06 原子回写 |
| `data/store/SecretBox.kt` | 91 → 102 | BUG-07 `tryOpen`、RISK-04 日志 |
| `data/webdav/DavHttp.kt` | **213 → 124** | PERF-01 / 07、RISK-02（整体替换传输层） |
| `data/webdav/WebDavStorage.kt` | 425 → 450 | BUG-05 / 11、RISK-03 / 10 |
| `data/smb/SmbClient.kt` | 469 → 488 | RISK-01 |
| `data/player/SmbDataSource.kt` | 381 → 402 | RISK-08 / 09 |
| `ui/player/PlayerState.kt` | 1007 → 1023 | BUG-01 / 08 / 10 / 12、PERF-08 |
| `ui/player/PlayerActivity.kt` | 205 → 218 | BUG-09、RISK-12 注释 |
| `data/scrape/Scraper.kt` | 257 → 268 | PERF-05 |
| `data/scrape/Http.kt` | 280 → 285 | RISK-11 注释澄清（逻辑未改） |
| **合计** | **4673 → 4805（+132）** | 其中 DavHttp 净减 89 行 |

### 测试代码（1 个已有文件）
- `app/src/test/java/com/eleventv/tv/data/webdav/DavHttpTest.kt`：新增 1 条「连续 PROPFIND 复用同一条 TCP 连接」用例 + 1 条「不发 `Connection: close`」断言，用于把 PERF-01 的核心收益变成可复现断言。用例数 3 → 4，全仓 61 → 62。

### 未改动（特意保留）
- `app/build.gradle.kts`、`gradle/libs.versions.toml`：**零新增依赖**。
- `data/model/Models.kt`、`data/repo/Mappers.kt`、`data/scan/FilenameParser.kt`、`data/smb/SmbStorage.kt`、`data/storage/RemoteStorage.kt`、`data/repo/ElevenRepository.kt`、`ui/App.kt`、`MainActivity.kt`、`ui/screens/*`、`ui/components/*`、`PlayerScreen.kt`：保持现状。
- 所有公开接口与数据模型字段：未改动，已有 `library.json` / `servers.json` / `playback.json` 可直接读取。

## 五、量化收益汇总

| 指标 | 改动前 | 改动后 |
|---|---|---|
| WebDAV 扫描 N 个目录的 TCP 连接 | N 次（HTTPS 另加 N 次 TLS 握手） | 1 次 + 连接池复用（单测已断言 accept=1） |
| `DavHttp.kt` 代码量 | 213 行（手写 socket + 三套响应解析） | 124 行（-42%） |
| `scan()` 继承刮削的复杂度 | O(F × P)，2000 条约 400 万次比较 | O(F + P) |
| `homeRows()` 全表扫描 / 排序 | 6 次 | 1 次分桶 + 组内排序 |
| 1000 条刮削的整库序列化 + fsync | 200 次 | 约 50 次 |
| 单条刮削 `enrich` 耗时 | `T_豆瓣 + T_fanart` 串行 | `max(T_豆瓣, T_fanart)` 并行 |
| `buildEntry` 每 bucket 全量遍历 | 3 次 + 3 个临时 Map | 1 次 + 复用投票表 |
| PROPFIND 单次响应体上限 / 峰值 | 32MB / 约 64MB | 16MB / 约 32MB |
| 新增依赖 / 新增技术栈 | — | 0 |

## 六、回归范围与真机验证清单

改动集中在「扫描 / 刮削 / 落盘 / 播放生命周期 / WebDAV 传输」，合并前建议按以下顺序回归：

1. **WebDAV 传输层（改动最大）**：自签证书 HTTPS 报错文案、401/403/404/405、302 补斜杠、chunked 响应、几千集大目录 PROPFIND；抓包统计 1000 目录扫描的 TCP 连接数，对比改造前（预期从 ~1000 降到个位数）。
2. **SMB 播放**：正常播放 / seek / 暂停恢复 / 播完自动下一集；长度未知片源（`FILE_STANDARD_INFORMATION` 被拒）的 EOF 与跳集行为；扫描进行中退出应用。
3. **扫描与落盘**：10 层嵌套目录、中文与空格目录、多版本数字文件名；断网冷启动；人为截断 `library.json` 后启动的恢复流程；删除服务器后 `.bak` 是否可用。
4. **播放器生命周期**：播完电影按 OK 重播（进度条 / `playback.json` / 超时提示）；无 duration 的 `.ts` 续播；注入 IO 失败后立刻选集换片；Keystore 重置后重启并保存服务器。
5. **性能基线**：5000 条库首页 Macrobenchmark 帧率；2000 条旧库重扫耗时；1000 条刮削总耗时与整库写盘次数。

## 七、汇总：已处理项与整体结论

### 处置统计（33 条）

| 处置 | 条数 | 条目 |
|---|---|---|
| **完整修复 / 优化** | **21** | BUG-01/02/03/05/06/08/09/10/11/12（10）；PERF-01/02/04/07/08（5）；RISK-01/02/05/06/07/08（6）。其中 PERF-07、RISK-02 由 PERF-01 一并解决 |
| **部分处理**（代码层已守住，UI/接口层按约束未动） | **8** | BUG-07、PERF-03、PERF-05、PERF-06、RISK-03、RISK-04、RISK-09、RISK-10 |
| **有意不做**（附工程取舍理由） | **4** | BUG-04、PERF-09、RISK-11、RISK-12 |
| **合计** | **33** | 12 Bug + 9 性能 + 12 风险 |

> 部分处理的 8 条，共同原因是「剩余动作需要改公开接口或用户可见交互」，与「接口行为与兼容性不变、仅调整报告涉及范围」冲突：BUG-07 数据保护已做、UI 提示未加；PERF-03 分桶已做、派生字段缓存未做；PERF-05 并行已做、结果缓存未做；PERF-06 单次投票与 `none` 已做、并查集未做；RISK-03 做了 URL 脱敏、未加设置页警示；RISK-04 做了日志留痕、未加 UI 提示；RISK-09 做了原子计数、未做 sessionId 隔离；RISK-10 做了重试退避、未做失败路径清单。

### 四条「有意不做」的理由（一句话版）

- **BUG-04**：改 `stableId` 规则会让已有库所有 id 漂移，直接违反兼容性约束；已有 `fileId` 兜底 + BUG-03 修复已消除主要翻转来源。
- **PERF-09**：目录并发会改变遍历顺序、进度回调语义与 `onFile` 线程安全假设，需 NAS 端压测；PERF-01 已覆盖主要瓶颈收益。
- **RISK-11**：缺 IPv6 投毒实测样本，硬编码新段是猜测；配置化机制会新增接口。
- **RISK-12**：无真机回归前猜系统私有 API 属于引入未提及的技术；反射已是安全降级，补注释写明边界与回归步骤。

### 整体结论

本次在**不新增任何依赖、不改动任何公开接口与数据模型、不动 UI 页面**的前提下，完成了 33 条审查发现中 **21 条完整修复、8 条代码层部分处理**，并对 4 条给出明确的工程取舍与后续路径。

最实质的收益有三处：**WebDAV 传输层从「每目录一次 TCP 握手」改为连接池复用**（并由新增单测 `accepts == 1` 实证），**扫描/首页/落盘三处高复杂度路径降为线性或单次遍历**，以及**播放器重播后进度与落盘失效、深目录静默丢片、Keystore 重置覆盖密文**三个会直接造成用户数据/体验损失的缺陷被关闭。

验证侧：改动前编译基线通过 → 4 个批次增量编译逐批通过 → 最终 `compileDebugKotlin` 无新增告警 → **62/62 单元测试通过** → `assembleDebug` 产出 20MB APK。静态核验确认零新增依赖、零新增 `!!`/`GlobalScope`/`runBlocking`，新增的 `Thread.sleep` 全部落在 `Dispatchers.IO`。

**必须说清的边界**：编译与单测只证明「代码可构建、契约未破坏、连接复用成立」，**不等于线上已验证**。NAS 端到端扫描耗时、OOM、屏保、Keystore 重置、播放重播等场景需按第六节清单在真机/灰度中回归；厂商 ROM 与系统版本行为以实测为准。修复代码合入前仍需走完整 Code Review 与灰度观察。



