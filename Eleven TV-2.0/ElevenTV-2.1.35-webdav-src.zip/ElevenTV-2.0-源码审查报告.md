# ElevenTV 2.0 源码系统性审查报告

审查对象：`ElevenTV-2.0-源码包.zip`（解压至 `ElevenTV-2.0-src/`），Android TV 本地媒体库应用，Kotlin + Jetpack Compose + Media3，共 30+ 个 Kotlin 源文件。

审查范围：`data/smb`（SmbClient/SmbPool/SmbStorage）、`data/webdav`（WebDavStorage/DavHttp）、`data/scan`（Scanner/FilenameParser）、`data/player`（SmbDataSource）、`data/repo`（LocalRepository/Mappers）、`data/store`（JsonStore/SecretBox）、`data/scrape`（Http/Scraper/ScrapeSources）、`data/model`（Models）、`ui/player`（PlayerState/PlayerActivity/PlayerScreen）、`ui`（App/MainActivity）、`ui/screens`、`ui/components`。

方法说明：全部结论均以 `cat -n` / 字节转储复核过原始字节后给出，行号可直接定位。审查中发现终端把源码里的 `String?` 渲染成了另一个词，属显示伪影，已排除，未计入发现。

## 结论概览

| 类别 | 高 | 中 | 低 | 合计 |
|---|---|---|---|---|
| 潜在 Bug | 3 | 8 | 1 | 12 |
| 性能瓶颈 | 2 | 6 | 1 | 9 |
| 风险与边界 | 2 | 9 | 1 | 12 |

最该先修的三处：**BUG-01（播完重播后进度与落盘全失效）**、**BUG-02（深目录静默丢片）**、**PERF-01（WebDAV 每目录新建 TCP，且"没有 OkHttp 依赖"的前提是错的）**。

---

## 一、潜在 Bug

### BUG-01【高】播完后重播，`ticker` 不再恢复，进度同步与 5 秒落盘全部失效

- **位置**：`ui/player/PlayerState.kt:865-876`（`onPlaybackStateChanged` 的 `STATE_ENDED` 分支）、`:213-222`（`togglePlayPause`）、`:748-749`（`start` 重新挂 ticker）
- **触发条件**：单集内容或关闭「自动下一集」后播到片尾，再按 OK / 播放暂停键重播。
- **根因**：`STATE_ENDED` 且无下一集时执行 `handler.removeCallbacks(ticker)`（L875）以「停止空转」。`togglePlayPause()` 在 `STATE_ENDED` 分支只做 `player.seekTo(0); player.play()`（L215-216），**没有重新 post ticker**。而 `syncProgress()` 只在 ticker 里跑，负责 `positionMs/durationMs/bufferedMs/isBuffering` 同步、每 5 秒 `saveProgress()`（L824-828）、12 秒取流超时提示（L804-817）。只有 `start()`（换集/重试/切解码器）会重新挂上，重播这条路径不走 `start()`。
- **后果**：重播后进度条冻结、断电/退出时丢进度、卡住时不再出现「读取超时」提示。用户会以为播放器坏了。
- **最小修复**：抽出 `ensureTicker()`（`removeCallbacks(ticker)` + `post(ticker)`），在 `togglePlayPause()` 的 ENDED 分支、`retry()`、以及 `onPlaybackStateChanged(STATE_READY)` 里调用；或干脆不在 ENDED 停 ticker（500ms 一次的开销可忽略）。
- **验证方式**：播完一部电影按 OK 重播，观察进度条是否走动；播放 2 分钟后退出，检查 `playback.json` 的 `positionMs` 是否更新；制造取流卡顿，看是否还弹超时提示。

### BUG-02【高】目录深度超过 8 层被静默跳过，不计入 `failedDirs`，两条保护逻辑都不触发

- **位置**：`data/scan/Scanner.kt:230`（`if (depth > MAX_DEPTH) return 0`）、`:426`（`MAX_DEPTH = 8`）；关联 `data/repo/LocalRepository.kt:323` 与 `:338`
- **触发条件**：NAS 上存在第 9 层及更深的子目录（多季/多版本/按清晰度分层存放时很常见）。
- **根因**：把「深度保护」当成正常返回，`return 0` 而不是计入失败。`failedDirs` 保持 0，于是 `LocalRepository.scan()` 既不会走「零结果保留旧库」（L323），也不会走「失败目录增量合并、保留上次条目」（L338-349），任务栏还会显示「扫描完成」。
- **后果**：深层目录里的影片无声消失，且旧库被整表覆盖，用户无法察觉是「没读到」而不是「删掉了」。这与该文件 L30-36 明确想解决的问题正好相反。
- **最小修复**：改为 `Log.w(TAG, "目录层级过深，已跳过：$path"); return 1`，让上层进入增量合并保护；或把深度上限改成可配置并在 UI 提示。
- **验证方式**：构造 10 层嵌套目录、最深层放 1 个合法 mkv，对比扫描前后 `entries.size` 与 `ScanResult.failedDirs`；再验证旧库条目是否被保留。

### BUG-03【高】`splitByIdentity` 并入无年份文件时未同步集号集合，同名剧会被错误合并

- **位置**：`data/scan/Scanner.kt:349-351`（`clusters.maxByOrNull { it.files.size }?.files?.addAll(unknown)`）、`:361`（`clusters[i].eps.intersect(clusters[j].eps).isEmpty()`）
- **触发条件**：同一归一化剧名下，同时存在带年份与不带年份的文件（目录不写年份是常态，见 L335 注释），且存在两部同名不同剧。
- **根因**：只把 `unknown` 加进 `files`，没有把它们的集号加进该簇的 `eps`。后续「是否为同一部剧」的判据完全是 `eps` 集合是否相交，偏小的 `eps` 更容易被判为 `disjoint=true`（L363），从而把本该拆开的两部剧合并成一条。
- **后果**：详情页出现两个 S01E01、刮削只能命中其中一部、`stableId` 变化导致历史数据失联——正是 L295-300 声称要避免的情形。
- **最小修复**：`?.let { c -> c.files.addAll(unknown); c.eps.addAll(epKeys(unknown)) }`。
- **验证方式**：构造两个不同年份的同名剧簇 + 一批无年份 `S01E01/E02` 文件，断言 `splitByIdentity` 返回 2 个 `Part`；补一条回归单测。

### BUG-04【中】`stableId` 在「同名剧拆分状态」变化时会整体漂移

- **位置**：`data/scan/Scanner.kt:316-320`（`idKey` 仅在 `parts.size > 1` 时追加年份）、`:412-422`（`stableId`）
- **触发条件**：两次扫描之间，文件命名/年份信息变化导致 `splitByIdentity` 的 `parts.size` 在 1 与 2 之间翻转（增删集、改名、刮削补年份后重扫）。
- **根因**：同一份内容在拆分状态为 1 时 id = `mergeKey`，为 2 时 id = `mergeKey|year`，**全部条目的 id 同时改变**。L312-315 的注释明确说要避免「季数一变 id 就变」，实现只覆盖了季数，没覆盖拆分状态。
- **缓解**：`inheritScrape` 按 `fileId` 继承（L295-296）、`remapPlayback` 按 `fileId` 重挂（L507-520），能救回大部分数据；但焦点恢复意图（`App.kt:106`）、详情页路由 `entryId`、同标签筛选等仍会失联。
- **最小修复**：id 恒定使用同一构成（例如始终带一个稳定的 part 序号），或在 `LocalRepository` 维护 `oldId → newId` 映射表并迁移引用。
- **验证方式**：同一批文件做两次扫描，第二次给部分文件加年份，diff 两次 `library.json` 的 `id` 集合，断言除真正新增/删除外保持不变。

### BUG-05【中高】WebDAV `isSelf` 判定依赖 href 编码形式，失败时目录会递归进自己

- **位置**：`data/webdav/WebDavStorage.kt:301`（`selfPath`）、`:340-352`（`isSelf` 与 `out +=`）、`:368-377`（`decodedPath`）；关联 `data/scan/Scanner.kt:242`（`walk` 递归）
- **触发条件**：服务器返回的第一条 `<href>` 与请求 URL 编码形式不一致 —— 绝对 URL vs 相对名、`%20` vs 空格、末尾斜杠有无、大小写差异。各家 NAS 前缀与编码差异见 L303-306 注释。
- **根因**：`isSelf = path.trimEnd('/') == selfPath` 是严格字符串相等。`selfPath` 来自 `URI(requestUrl).path`，`path` 来自 `URI(href).path`；两者虽都解码，但只要服务器给的 href 形态不同就不相等。判定失败后目录自身被当成子项加入 `out`，`walk()` 会把它当目录再递归一层。
- **后果**：递归直到 `MAX_DEPTH=8`，产生重复路径与幽灵条目，同一批文件被重复扫描（`seenIds` 按 `serverId|share|relPath` 去重，路径不同则拦不住）。
- **最小修复**：① `isSelf` 改为规范化比较（统一解码、`trimEnd('/')`、去掉 query），或直接比较 `URI.resolve` 后的绝对 URL；② 在 `walk()` 里维护 `visited` 路径集合防环，这是更兜底的一层。
- **验证方式**：用返回绝对编码 href 的 WebDAV 服务（nginx/lighttpd 不同配置）扫描含中文与空格的目录，检查是否出现同名重复条目、`ScanProgress.currentPath` 是否出现重复层级。

### BUG-06【中】从备份恢复时用非原子 `copyTo` 回写主文件，绕过了本类最核心的保护

- **位置**：`data/store/JsonStore.kt:76-89`（`restoreFromBackup`，L87 `bak.copyTo(file, overwrite = true)`）；对比 `:109-126`（`write` 的 tmp + `fd.sync()` + `ATOMIC_MOVE`）
- **触发条件**：主文件损坏（断电截断）→ `quarantine()` 把损坏文件改名移走（L105）→ 从 `.bak` 恢复 → 恢复写入过程中再次断电/进程被杀。
- **根因**：`quarantine` 已经把主文件挪走，此时磁盘上唯一可能成为新主文件的就是这个普通 `copyTo`，它既没有 `fd.sync()` 也没有原子 rename。L23-32 用整段注释说明了「rename 前必须 fsync，否则 0 字节文件看起来像合法空数组」，恢复路径恰恰违反了这一点。
- **后果**：恢复过程中断电得到一个半截 `library.json`，下次启动又走一次损坏流程；若此时 `.bak` 也被覆盖，媒体库彻底丢失。
- **最小修复**：`restoreFromBackup` 里改用 `write(deserializer, value)` 把 `value` 写回主文件（复用原子写），而不是 `copyTo`。注意 `restoreFromBackup` 目前只拿到反序列化后的 `T`，签名需带上 `SerializationStrategy<T>`。
- **验证方式**：在 `copyTo` 执行中途 kill 进程 / 断电模拟，检查主文件是否为完整 JSON；补一条针对恢复路径的原子性单测。

### BUG-07【中高】Keystore 重置后空密码会被回写，永久覆盖原密文，且用户只看到「用户名或密码错误」

- **位置**：`data/store/SecretBox.kt:51-61`（解密失败 `return ""`）、`:38-39`（`seal` 对空串直接返回）；`data/repo/LocalRepository.kt:103-104`（`init` 把空串放进内存）、`:132-138`（`persistServers`）；`data/smb/SmbClient.kt:271-272`（错误文案）
- **触发条件**：系统升级、恢复出厂、清除凭据存储导致 AndroidKeyStore 条目丢失（注释 L26 已承认这是唯一可能）。
- **根因**：解密失败返回空串后，内存中的 `SmbServer.password` 变成 `""`；此后任何一次 `saveServer` / `persistServers` 都会 `SecretBox.seal("")` → 因 `plain.isEmpty()` 直接返回空串 → **明文空密码落盘，原 `enc1:` 密文被覆盖**。同时连接失败被翻译成「认证失败：请检查用户名与密码」，用户会反复改密码而不知道要重填。
- **后果**：凭据不可逆丢失；排障方向被误导。
- **最小修复**：`open()` 失败时返回可区分结果（如 `null` 或专用异常），`init()` 检测到后**保留原始密文字符串**、把该服务器标记为「需重新填写密码」并在设置页提示；`persistServers` 跳过标记为待重填的条目，避免回写。
- **验证方式**：清除应用 AndroidKeyStore 条目后重启，检查 `servers.json` 的 `password` 字段是否保持 `enc1:` 前缀；再触发一次「保存服务器」，确认密文未被空串覆盖。

### BUG-08【中高】无容器时长的片源（TS/m2ts/ISO）永远不会保存播放进度

- **位置**：`ui/player/PlayerState.kt:761-766`（`saveProgress`）、`:769`（`syncProgress` 把 `durationMs` 置 0）、`:752-759`（`resumePositionOf`）；`data/model/Models.kt:441-446`（`progress` / `finished`）
- **触发条件**：播放没有 duration 元数据的文件，`player.duration == C.TIME_UNSET`。
- **根因**：`saveProgress()` 第一行 `val duration = durationMs.takeIf { it > 0 } ?: player.duration.takeIf { it > 0 } ?: return` —— 两个来源都 ≤ 0 就直接 return，连 `positionMs` 都不写。而 `syncProgress()` 在 `duration` 不可用时把 `durationMs` 设为 0，`PlaybackRecord` 也就永远不会被创建。
- **后果**：这类片源的续播、「继续播放」行、进度条全失效；`homeRows()` 的 `records[entry.id]` 恒为 null。
- **最小修复**：允许 `durationMs = 0` 的占位记录（保存 `positionMs` + `updatedAt`），`resumePositionOf` 据此恢复；`PlaybackRecord.progress` 在 `duration<=0` 时按 0 处理、`finished` 不触发（现有实现已兼容）。另可按 `sizeBytes / 估算码率` 给一个粗略时长供进度条显示。
- **验证方式**：播放一个无 duration 的 `.ts` 5 分钟退出，检查 `playback.json` 是否生成记录；再次进入，检查是否从上次位置续播。

### BUG-09【中】`fileId` 失效时静默回退到第一集

- **位置**：`ui/player/PlayerActivity.kt:50-65`（L54 `firstOrNull { it.id == fileId } ?: entry?.primaryFile`）；关联 `data/scan/Scanner.kt:115`（`id = serverId|share|relPath`）
- **触发条件**：重新扫描后文件路径/服务器配置变化导致 `fileId` 改变，用户从「继续播放」或详情页点开旧记录。
- **根因**：回退到 `primaryFile`（第一集）不产生任何提示，且 L56-64 的「内容已不在媒体库」分支只在 `entry == null || file == null` 时触发，这里 `file` 非空所以不会进入。
- **后果**：用户点「继续观看 · S2E05」却从第 1 集开始播放，看起来像进度丢失。
- **最小修复**：`fileId` 找不到时按 `(seasonNumber, episodeNumber)` 或 `path` 二次匹配；仍找不到则 Toast 明确提示「该集已变更，将从头播放」。
- **验证方式**：扫描后重命名一个分集文件，重扫，从首页「继续播放」进入，观察实际播放的集与提示。

### BUG-10【中】自动重试的 1 秒延迟任务没有绑定播放目标，会打断用户换集/切解码器

- **位置**：`ui/player/PlayerState.kt:909-924`（`onPlayerError`，L922 `handler.postDelayed({ if (!released && error == null) retry() }, AUTO_RETRY_DELAY_MS)`）、`:284-286`（`retry`）、`:245-252`（`playFile`）、`:261-276`（`switchDecoder`）
- **触发条件**：一次可恢复的取流失败后，在 1 秒静置期内用户按「选集」换片或切换解码方式。
- **根因**：延迟任务只检查 `released` 与 `error == null`，这两个条件在换集/切解码器后依然成立；`retry()` 读取的是**当前** `file` 与 `positionMs`，于是把用户刚发起的新播放重新 `start()` 一遍。
- **后果**：换集被拉回、解码器切换被覆盖、进度回跳。
- **最小修复**：引入 `playGeneration` 计数，`start()` 递增；延迟任务捕获当时的值，执行前比对不等则放弃。或在 `playFile` / `switchDecoder` / `start` 开头 `handler.removeCallbacks` 掉待执行的重试 Runnable（把它存成字段）。
- **验证方式**：注入一次 IO 失败触发自动重试，立刻按选集换片，观察是否被拉回原片；加一条针对 `playGeneration` 的单测。

### BUG-11【中】PROPFIND 的 3xx 重定向沿用原方法，303 场景会失败

- **位置**：`data/webdav/WebDavStorage.kt:229-236`（`REDIRECTS` 递归 `request(next, depth, hop + 1)`）、`:410`（`REDIRECTS = setOf(301,302,303,307,308)`）、`data/webdav/DavHttp.kt:52-59`（`method` 参数原样透传）
- **触发条件**：服务器对缺少末尾斜杠的目录返回 301/302/303 补斜杠（NAS 上很常见），或 http→https 跳转。
- **根因**：`request()` 递归时始终传 `"PROPFIND"`；按 HTTP 语义 303 应改为 GET，部分服务器对 302 的 PROPFIND 也直接回 405。且 L234 用 `URI(url).resolve(location)` 时若 `location` 是相对路径且请求 URL 已编码，可能产生二次编码。
- **后果**：`davRepairCase()`（L60、L90）与目录浏览的探测请求误判为「连不上」，给出错误的排障建议。
- **最小修复**：303 改为不自动跟随并把最终 URL 提示给用户；301/302/307/308 保留 PROPFIND 但校验跳转目标同源、限制 `hop`；对跳转后的 URL 记录日志。
- **验证方式**：搭建返回 302 补斜杠的 WebDAV 服务，执行「测试并保存」，观察 `davNotFoundHint()` 的结论是否准确。

### BUG-12【低】`PlayerState.seekTo(ms)` 是死代码，且内部藏着一个已被 `seekBy` 规避的坑

- **位置**：`ui/player/PlayerState.kt:238-242`（`private fun seekTo`）；对比 `:224-236`（`seekBy`）、`ui/player/PlayerScreen.kt:425-466`（进度条只读）
- **说明**：全仓检索确认 `seekTo(ms)` 无任何调用点；进度条 `ProgressTrack` 只渲染，不支持拖拽/点击定位。`seekBy` 在 L230-233 用整段注释规避了「duration 未知时 `coerceIn(0,0)` 把目标压成 0」，但 `seekTo(ms)` 仍写 `ms.coerceIn(0L, durationMs.coerceAtLeast(0L))`，起播瞬间 `durationMs=0` 会把目标一律压成 0。
- **风险**：一旦后续给进度条加拖拽并复用这个私有方法，会立刻出现「拖到 50% 跳回片头」。
- **最小修复**：删除该死方法；若要做拖拽定位，复用 `seekBy` 的时长兜底逻辑并抽成公共函数。
- **验证方式**：全局搜索 `seekTo(` 调用点确认；补一条「duration=0 时 seekBy(+10s) 不回 0」的回归单测。

---

## 二、性能瓶颈

### PERF-01【高】WebDAV 每个目录新建一次 TCP 连接（HTTPS 还加 TLS 握手），且「没有 OkHttp 依赖」的前提不成立

- **位置**：`data/webdav/DavHttp.kt:74-103`（`openSocket` → `connect` → `Connection: close`(L91) → `finally close`）、`:35-37`（注释）；`data/scan/Scanner.kt:224-245`（串行 DFS `walk`）；`data/scrape/Http.kt:15-17`（`import okhttp3.OkHttpClient / Request / Dns`）
- **问题**：`Scanner.walk()` 是单线程深度优先递归，每个目录调一次 `storage.list(path)`；WebDAV 侧每次 `list` 都走 `DavHttp.exchange()` 新建 Socket、connect、发 `Connection: close`、关闭。几百个目录 = 几百次串行 RTT；HTTPS 下每次还要完整 TLS 握手。这是 WebDAV 扫描慢的主因。
- **关键矛盾**：`DavHttp.kt:35-37` 的注释明确写着「要绕开 HttpURLConnection 的方法白名单就得直接依赖 OkHttp，而本项目是离线构建、缓存里没有它，一个 PROPFIND 只需要一次请求，手写这 180 行比引入一个依赖划算」。但刮削模块 `data/scrape/Http.kt` **已经在使用 okhttp3**（`OkHttpClient.Builder()`、`Request.Builder()`、`Dns`），依赖显然在 classpath 上。这个错误前提导致重复实现了一套无连接池、无 HTTP/2、无自动重定向、无 TLS 会话复用的 HTTP 客户端，也是 BUG-11 与 RISK-02 的共同来源。
- **可落地优化**：用 OkHttp 的自定义方法 `Request.Builder().url(url).method("PROPFIND", body.toRequestBody())` 替换 `DavHttp.exchange`，直接获得连接池、TLS 会话复用、自动重定向与超时统一配置；`WebDavStorage` 里 `request()`（L229-236）的手工跟跳转逻辑、`DavHttp` 整个 212 行都可删掉。短期若不动架构，至少在 `DavHttp` 内按 host:port 复用 keep-alive Socket 并去掉 `Connection: close`。
- **验证方式**：1000 目录 WebDAV 库扫描计时 + 抓包统计 TCP 连接数 / TLS 握手次数，对比改造前后；确认 `./gradlew :app:dependencies` 中 okhttp3 存在。

### PERF-02【高】`scan()` 对每个新条目线性扫描整个旧库

- **位置**：`data/repo/LocalRepository.kt:308-314`（`entry.files.mapNotNull { previousByFile[it.id] } ... ; previous.firstOrNull { it.id == oldId }`）
- **复杂度**：设新条目数 F、旧条目数 P，`previous.firstOrNull` 是 O(P)，嵌套在 `fresh.map` 里 → **O(F × P)**；另每条都做一次 `files.mapNotNull` + `groupingBy().eachCount()` + `maxByOrNull`。2000 条旧库约 400 万次字符串比较。
- **可落地优化**：L292 附近一次性 `val previousById = previous.associateBy { it.id }`，L313 改 `previousById[oldId]`，降为 O(F)。同一函数 L339-342 的 `fresh.none { it.id == old.id }` 也是 O(F × P)，应预建 `val freshIds = fresh.mapTo(HashSet()) { it.id }`。
- **验证方式**：构造 2000 条旧库重扫，用 `System.nanoTime()` 或 Android Studio Profiler 对比 `scan()` 耗时与 `firstOrNull` 的 CPU 占比。

### PERF-03【中高】`homeRows()` 每次调用做 6 次全表扫描 + 6 次排序，且角标计算逐文件跑正则

- **位置**：`data/repo/LocalRepository.kt:600-643`（`homeRows`）、`data/repo/Mappers.kt:68-84`（`badgeList`）；调用侧 `ui/App.kt:197`
- **已核验正确**：调用侧 `ui/App.kt:197` 已有 `val homeRows = remember(library, playback) { repo.homeRows() }`，避免了「每次重组都重算」，这点不是缺陷。
- **剩余问题**：`library` / `playback` 都是高频变更的 StateFlow —— 刮削期间 `mergeAndSave` 每 5 条更新一次 `_library`（L419、L489-498），播放期间 `saveProgress` 每 5 秒更新一次 `_playback`（L683-695、PlayerState.kt L824-828）。任一变化都会让 `remember` 的 key 失效并**重算整个 `homeRows()`**：`associateBy` 一次 + `continueItems` 全表 `mapNotNull/sortedByDescending` + `for (kind in HOME_KINDS)` **5 次** `filter + sortedByDescending + take(16)`，每次 O(n log n)。
- **叠加开销**：每个 `toSummary()` → `badgeList()` 遍历该条目**全部文件**并调用 `FilenameParser.qualityOf` / `dynamicRangeOf`（正则），首页 6 行 × 16 条 × 几十文件 ≈ 上千次正则匹配；`subtitleText()` 还会重复计算 `seasons`。
- **可落地优化**：① 仓库内维护「按 kind 分组且按 `addedAt` 降序」的索引，在 `_library` 变更时增量重建一次，`homeRows()` 只做 `take`；② 把 `badges` / `seasons` 作为派生字段缓存到 `LibraryEntry`（扫描或刮削落库时算一次并持久化）；③ 把 `homeRows` 的 key 从整个 `library` 收窄为实际影响行的字段版本号，避免刮削中间态触发无谓重算。
- **验证方式**：5000 条目库、后台刮削 + 播放同时进行的场景下用 Macrobenchmark 测首页帧率；Method Trace 看 `homeRows()` 与 `FilenameParser.*Of` 的调用次数与耗时占比。

### PERF-04【中】每 5 条刮削结果就把整库 JSON 全量序列化 + fsync + 原子替换

- **位置**：`data/repo/LocalRepository.kt:417-425`（`if (n % 5 == 0) mergeAndSave(merged)`）、`:489-498`（`mergeAndSave`）、`:577-587`（`saveLibrary`）；`data/store/JsonStore.kt:109-126`（`write`）
- **问题**：每次 `saveLibrary()` 都 `json.encodeToString` 整个媒体库（几百 KB～数 MB）→ `ByteArray` → `FileOutputStream` + `fd.sync()` → `ATOMIC_MOVE`。1000 条刮削 = 200 次全量序列化与 fsync。注释 `JsonStore.kt:60-66` 已说明「备份不每次做」的权衡，但主写盘仍是全量。在低端电视盒子上，同步刷盘会明显拖慢刮削并加剧 I/O 抖动。
- **可落地优化**：批量阈值从 5 提到 20~50（配合 UI 增量刷新可改为发轻量进度事件而非整表快照）；或改成追加式 journal / 引入 Room；至少保证「刮削结束时一次全量写」并对中间态只更新内存。
- **验证方式**：统计刮削 1000 条期间 `JsonStore.write` 的调用次数、累计写入字节与 `fd.sync()` 总耗时；对比阈值调整后的整库刮削总时长。

### PERF-05【中】单条刮削串行发起十余次网络请求，`enrich` 内的补充源也未并行

- **位置**：`data/scrape/Scraper.kt:37-103`（`scrape` 的 query 阶梯 × 候选重试 × 豆瓣降级）、`:158-188`（`enrich` 顺序调豆瓣与 fanart）；`data/repo/LocalRepository.kt:402-423`、`:736`（`MAX_SCRAPE_CONCURRENCY = 3`）
- **问题**：单条最坏路径 = 3 个 query × (1 次 search + 最多 3 次 detail) + `enrich` 的豆瓣 + fanart + 失败后的豆瓣降级，十余次串行往返。`enrich()` 里豆瓣（L163）与 fanart（L181-184）互不依赖却顺序执行。整体并发被 `Semaphore(3)` 限制，几百条库刮削耗时线性放大。
- **可落地优化**：① `enrich` 内用 `coroutineScope { val db = async{...}; val fan = async{...} }` 并行；② 进程内缓存 TMDB `search/detail`（同一部剧多集、force 重刮会重复查）；③ 对 401/429 做全局短路 —— 目前只有「某 query 的 search 返回空且 `lastError() != null`」才 `break`（L62-63），限流时其余 query 仍会各等一次超时。
- **验证方式**：统计单条平均请求数与整库刮削总耗时；在 429 限流场景下对比改造前后的失败收敛速度。

### PERF-06【中】扫描归并阶段多次全表遍历，`splitByIdentity` 最坏 O(k³)

- **位置**：`data/scan/Scanner.kt:263-270`（`numericEpisodeDirs` 全表）、`:163-189`（`raw` → `found` 全表 parse）、`:302-325`（`groupEntries`）、`:338-377`（`splitByIdentity` 的 `while(merged)` 嵌套双循环 + `intersect`）、`:385-409`（`buildEntry` 三次 `groupingBy().eachCount()`）
- **问题**：整体是 O(n) 但常数高；`splitByIdentity` 每轮合并都重扫所有簇对并做集合 `intersect`，最坏 O(k³)（k = 年份簇数，通常很小，实际影响有限但仍是可优化点）。`buildEntry` 对同一 `items` 做三次独立分组投票。
- **可落地优化**：合并改用并查集一次收敛；`buildEntry` 的 kind/year/title 三次投票合并为单次遍历累加；`FilenameParser.parse` 结果按 `(fileName, relPath, numericEpisode)` 做记忆化（同目录多季文件名相同的情况常见）。
- **验证方式**：上万文件库扫描计时，Profile 看 `splitByIdentity` 与 `FilenameParser.parse` 的占比。

### PERF-07【中】`DavHttp.readLine` 逐字节读头部，且注释与「调用方已 buffered」的事实矛盾

- **位置**：`data/webdav/DavHttp.kt:99`（`socket.getInputStream().buffered()`）、`:153-166`（`readLine` 逐字节 `input.read()` + `StringBuilder.append` + 长度检查）
- **问题**：虽然 `input` 已 buffered、`read()` 不是真系统调用，但每字节仍是一次方法调用 + StringBuilder 追加 + 越界检查；`MAX_HEAD_BYTES = 64KB`（L50）意味着单个畸形响应头最坏 6.5 万次迭代。L153 注释「响应头不大，不值得为此再包一层缓冲区」与 L99 已经包了缓冲的事实不一致，容易误导后续维护者。
- **可落地优化**：改用 `BufferedReader(InputStreamReader(input, ISO_8859_1)).readLine()`，或按块（8KB）扫描 `\r\n`；顺手修正注释。
- **验证方式**：构造带大量自定义响应头的 PROPFIND，对比改造前后 `readResponse` 耗时；补一条超长行触发上限的单测。

### PERF-08【低】`onCues` 无条件赋新列表，字幕内容不变也触发重组

- **位置**：`ui/player/PlayerState.kt:898-906`（`cues = texts` 无比较；`if (bitmaps != bitmapCues)` 有比较）
- **问题**：`texts` 每次都是新建 `ArrayList`，即使与上一帧内容完全相同，`mutableStateOf` 也会记录一次变更，触发字幕层重组。位图侧已有 `!=` 保护，文本侧缺失，属明显的不对称。
- **最小修复**：`if (texts != cues) cues = texts`。
- **验证方式**：连续字幕帧下用 Layout Inspector 统计字幕 Composable 的重组次数，对比修改前后。

### PERF-09【中】目录遍历完全串行，未按同层目录做有限并发

- **位置**：`data/scan/Scanner.kt:224-245`（`walk` 单线程 DFS）、`:143-152`（SMB 走 `pool.with`、WebDAV 走一次性 `use`）
- **问题**：SMB 侧已用连接池复用（正确），但一层里 N 个目录仍是 N 次串行 `list()` 往返。局域网 RTT 几十毫秒时，1000 目录就是几十秒纯等待。
- **可落地优化**：对同层子目录用 `Semaphore(4~8)` 做有限并发（注意 SMB 连接池容量与 NAS 并发承受力，需可配置）；WebDAV 必须先解决 PERF-01 的连接复用，否则并发只会放大握手开销。
- **验证方式**：1000 目录库在串行 / 4 路并发下分别计时，并观察 NAS 端是否出现 `STATUS_TOO_MANY_SESSIONS` 之类错误。

---

## 三、风险与边界

### RISK-01【高】`SmbPool.closeAll()` 不持锁、不检查 `busy()`，会关闭正在使用的连接

- **位置**：`data/smb/SmbClient.kt:428-432`（`(slots.values + zombies).forEach { runCatching { it.connection.close() } }`）；对比 `:385-400`（`use`）、`:446-456`（`retire` / `closeIfIdle` 的 `busy()` 判断）
- **风险**：池里其他路径都小心地用 `openHandles` + `activeOps` 判断「连接还在用」，`closeAll()` 却完全绕过。退出应用、删除服务器或进程清理时若扫描 / 播放正在进行，连接会被中途 `close()`，`SmbFile.read()` 抛 `SmbException`，播放中断或扫描丢一批条目。
- **边界**：`retire()` 本身也不持锁，`slots` 是 `ConcurrentHashMap`、`zombies` 是并发 Set，属于弱一致性遍历；`closeAll()` 与并发的 `with()` / `sweep()` 之间没有 happens-before 保证。
- **最小修复**：`closeAll()` 按 key 取 `lockOf(key)` 后逐个 `retire`，对 `busy()` 的 slot 只标记 retire、交由 `sweep()` 在空闲时关闭；或至少在关闭前检查 `busy()` 并记录警告。
- **验证方式**：扫描进行中调用 `closeAll()`，压测并发下的异常率与条目完整性；补一条「持句柄时 invalidate/closeAll 不打断读」的并发单测。

### RISK-02【高】单次 PROPFIND 响应体可达 32MB 且存在双份拷贝，低端盒子有 OOM 风险

- **位置**：`data/webdav/DavHttp.kt:48`（`MAX_BODY_BYTES = 32MB`）、`:168-179`（`readFixed` 直接 `ByteArray(length)`）、`:181-200` / `:202-211`（`ByteArrayOutputStream.toByteArray()` 再拷一份）；`data/webdav/WebDavStorage.kt:278`（`ByteArrayInputStream`）
- **风险**：`readChunked` / `readUntilEof` 峰值约为响应体的 2 倍（缓冲区 + `toByteArray()` 拷贝）；`readFixed` 在 Content-Length 恰好 32MB 时一次性分配 32MB 连续堆内存。电视盒子常见 512MB/1GB 内存，同期还有 Coil 图片缓存、`PlayerState.kt:690` 的 48MB 目标缓冲、`SmbDataSource.kt:271` 的 512KB 预读。大目录（几千集）叠加多协程扫描时可能触发 OOM 或大对象分配卡顿。
- **边界**：`out.size() + size > MAX_BODY_BYTES` 的检查在 `readChunked` L196 是 Int 相加，极端 `size` 值下可能整型溢出，导致上限检查被绕过（虽然 `readFixed` 内部 L170 还有一次检查）。
- **最小修复**：上限降到 8~16MB；让 `WebDavStorage.parse` 直接消费 `InputStream` 而不是先收成 `ByteArray`；`readChunked` 的上限判断改用 `Long` 累加。超大目录用分页 / 更窄的 Depth。
- **验证方式**：构造 30MB PROPFIND 响应，在低内存设备上观察 PSS 峰值与 GC 次数；构造畸形 chunk size 验证上限检查不会溢出绕过。

### RISK-03【中】WebDAV 凭据默认以 HTTP + Basic Auth 传输，等同于明文，且用户无感知

- **位置**：`data/webdav/WebDavStorage.kt:25-34`（`davAuthHeader` 返回 `Basic base64(user:pwd)`、`davRequestHeaders` 直接给 Media3）；`data/model/Models.kt:269-270`（`tls: Boolean = false`）；`data/webdav/WebDavStorage.kt:205-209`（证书失败时建议「改用 HTTP」）
- **风险**：`base64` 不是加密，HTTP 下同网段任意设备可嗅探到 NAS 账号密码；播放端 `DefaultHttpDataSource` 的默认请求头同样带这个 Authorization（`PlayerState.kt:650-651`）。L269 注释说明「局域网自签证书无法验证，通常直接用 HTTP」是有意取舍，但设置页与错误提示反而主动引导用户关掉 TLS，没有风险告知。
- **附带**：`WebDavStorage.kt:241` 把完整请求 URL 拼进错误文案（`where = "；请求 $url"`），会进 logcat 与 UI；当前 URL 只含路径不含凭据，风险有限，但若日后加 query token 就会泄露。
- **最小修复**：在「WebDAV + HTTP + 非空密码」组合下于设置页给出明确警示；支持导入自签证书 / 信任用户证书；错误文案打印前脱敏 URL 的 query。
- **验证方式**：抓包确认 Authorization 头是否明文；检查设置页在默认配置下是否有风险提示。

### RISK-04【中】Keystore 不可用时加密静默退化为明文落盘

- **位置**：`data/store/SecretBox.kt:38-49`（`seal` 的 `getOrElse { Log.w(...); plain }`）、`:51-52`（`open` 对无前缀值按明文返回）
- **风险**：`runCatching` 吞掉所有加密异常后直接把明文密码写进 `servers.json`，只有一条 `Log.w`，UI 无任何提示。`open()` 因兼容旧数据而把无 `enc1:` 前缀的值当明文处理，功能上不会出错 —— 正因如此，安全降级是完全静默的。
- **边界**：与 BUG-07 叠加时，Keystore 异常既可能让新密码明文落盘，也可能让旧密文被空串覆盖。
- **最小修复**：把「本次是否加密成功」作为返回值传出，落盘时对该状态做显式标记，并在设置页展示「当前设备不支持加密存储，密码以明文保存」；或在该状态下拒存密码、改为每次连接时输入。
- **验证方式**：在 `key()` 抛异常的设备/模拟环境下保存服务器，检查 `servers.json` 内容与设置页提示。

### RISK-05【中】「零结果保护」在首次扫描时不生效，NAS 不可达会被当成空媒体库

- **位置**：`data/repo/LocalRepository.kt:323-333`（`if (fresh.isEmpty() && previous.isNotEmpty())`）、`:356-366`（`JobStatus.Done`）
- **风险**：`previous` 为空（首次配置、刚清过库）时，`fresh` 为空会直接 `saveLibrary()` 写成空库，任务栏显示「扫描完成：0 部」。用户不会察觉这是失败。另外 `failedDirs > 0` 虽然进了 message（L362-364），状态仍是 `JobStatus.Done`，UI 若按状态渲染就不会突出警示。
- **边界**：`Scanner.walk` L231 用 `runCatching { storage.list(path) }.getOrElse { return 1 }` 吞掉目录失败，单个根读取失败 → 整棵子树跳过，只贡献 1 个 `failedDirs`。
- **最小修复**：首次扫描且 `fresh.isEmpty()` 时一律设为 `JobStatus.Failed` 并保留提示；`failedDirs > 0` 时给 `JobState` 增加 `warning` 字段或在 `message` 前置警示标记，让 UI 能区分。
- **验证方式**：配置好服务器后断开网络冷启动，观察任务栏状态与媒体库是否被写空。

### RISK-06【中】删除服务器会不可逆裁剪媒体库与播放记录，裁剪前没有备份

- **位置**：`data/repo/LocalRepository.kt:228-258`（`deleteServer`）；对比 `:351`（`scan()` 写盘前先 `libraryStore.backup()`）
- **风险**：L237-255 会按 `serverId` 裁剪 `entry.files`、删掉整条空条目、清掉失效的 `PlaybackRecord`，然后 `saveLibrary()` / `savePlayback()` 直接落盘。这是整库重建级别的不可逆操作，却没有像 `scan()` 那样先备份。误删服务器后无法从 `.bak` 找回。
- **边界**：`JsonStore.backup()` 只在 `scan()` 调用，意味着 `.bak` 的时间戳可能停留在很久以前，`restoreFromBackup` 能恢复的内容也受此限制（与 BUG-06 叠加）。
- **最小修复**：裁剪前 `libraryStore.backup()` + `playbackStore.backup()`；或改成逻辑删除 + 撤销入口 + 二次确认。
- **验证方式**：删除一台服务器前后检查 `library.json.bak` / `playback.json.bak` 的时间戳与内容。

### RISK-07【中】「数字文件名＝分集」的启发式会因目录内容变化翻转整部剧的形态与 id

- **位置**：`data/scan/Scanner.kt:263-282`（`numericEpisodeDirs` / `leadingEpisodeNumber`）、`:170`（`numericEpisode = r.dirKey in numericDirs`）
- **风险**：判据是「同目录 ≥2 个互不重复的 1~3 位数字开头文件」。`leadingEpisodeNumber` 把 `01.mkv` 与 `1.mkv` 都归一为 1，去重后 Set 只剩 1 个元素 → 不满足 `size >= 2`，该目录不会被识别为分集目录；反过来 `诺兰合集/01.mkv 02.mkv` 会被误判成一部剧（注释 L259-261 已承认）。
- **边界**：结论依赖**当前目录里有哪些文件**，所以增删一集、加一个不同压制版本，就可能让整部在「电影 / 剧集」之间翻转，进而改变 `mergeKey`、归类与 `stableId`（呼应 BUG-04）。
- **最小修复**：用 `(季, 集)` 归一化但保留多版本计数（同一集的多版本仍算「有多个文件」）；把阈值提到「≥3 个连续编号」；对已刮削过的条目优先沿用 `entry.kind` 而不是每次重猜。
- **验证方式**：目录放 `01.mkv` + `1.mkv` + `02.mkv`，断言被识别为分集目录；再补一个 `03.mkv` 前后对比 `LibraryEntry.kind` 与 `id` 是否稳定。

### RISK-08【中】未知文件长度时，一次 0 字节读取就被判为「播完」，可能是断线而非 EOF

- **位置**：`data/player/SmbDataSource.kt:220-222`（`if (bytesRemaining == Long.MAX_VALUE || attempt >= RECOVER_ATTEMPTS) return eof()`）、`:144-153`（`length < 0` → `bytesRemaining = Long.MAX_VALUE`）、`:302-312`（`reattach`）
- **风险**：当 NAS 拒绝 `FILE_STANDARD_INFORMATION`（注释 L145-146）时长度未知，若连接半死导致 `file.read` 返回 0，代码**立刻** `eof()`，不走重连。而 L220-221 的注释明确说「已知长度却还有剩余时先怀疑连接半死：重连再读一次」，未知长度恰恰最需要这个怀疑。
- **后果**：网络抖动被误报成播放结束，触发 `onPlaybackStateChanged(STATE_ENDED)` → `saveProgress()` + 自动下一集（`PlayerState.kt:865-869`），用户看到「跳集」。
- **最小修复**：未知长度时也允许有限次（如 1 次）`reattach` 重连，以「连续两次读到 0 字节」作为 EOF 判据；或让底层 `SmbFile.read` 在连接异常时抛异常而非返回 0（它已有 `closed` 检查，L73）。
- **验证方式**：模拟 SMB 连接静默断开但保持长度未知，观察是否直接跳到下一集；补一条「未知长度 + 单次 0 字节」的单测。

### RISK-09【中】`SmbIoStats` 是全局单例，多路播放 / 扫描并发时统计串台

- **位置**：`data/player/SmbDataSource.kt:26-76`（`object SmbIoStats`）、`ui/player/PlayerState.kt:727`（`reset`）、`:797-816`（`bufferHint` 直接读单例）
- **风险**：`reset(active=...)`、`bytesRead`、`active` 全是全局静态。若从最近任务再启动一个播放页，或播放与扫描并发，`active` 会被另一路覆盖，`summary()` 显示错误字节数，「SMB / WebDAV」协议标签也会串（L797-801）。不影响播放主流程，但会误导排障 —— 而这个统计的存在意义正是排障。
- **边界**：`@Volatile` 只保证可见性，`bytesRead += n`（L263、L280）、`readCalls++` 是读-改-写，多线程下会丢计数。
- **最小修复**：统计改为按 `SmbDataSource` 实例持有并由 `PlayerState` 注入，或至少加 `sessionId` 隔离；计数字段改 `AtomicLong` / `LongAdder`。
- **验证方式**：同时开两个播放页或边扫边播，观察 `bufferHint` 数值与协议标签；并发压测 `readCalls` 与 `bytesRead` 是否一致。

### RISK-10【中】WebDAV 重试无退避，且目录失败会让整棵子树被跳过

- **位置**：`data/webdav/WebDavStorage.kt:172-185`（`list()` 的 `while(true)` 立即重试一次）、`:269`（500/502/503/504 标 `retryable`）；`data/scan/Scanner.kt:231-234`（`runCatching` 吞异常并 `return 1`）
- **风险**：5xx / 超时 / 连接中断都用「立刻再请求一次」处理，没有指数退避；NAS 瞬时过载时两次请求几乎同时到达，可能加重故障。重试仍失败时 `walk` 直接跳过整个目录子树，只贡献 1 个 `failedDirs`。
- **缓解**：`LocalRepository.kt:338-349` 的增量合并会在 `failedDirs > 0` 时保留上次没见到的条目，这是正确的兜底；但 UI 只给一个汇总数字，用户不知道**具体哪个路径**没读到。
- **最小修复**：重试加 `delay(300~800ms)` 抖动；`ScanResult` 收集失败路径列表并在任务栏/设置页展示，便于定点复核。
- **验证方式**：注入一次 503，观察两次请求的时间间隔；检查失败目录名是否出现在 UI 提示中。

### RISK-11【低】DoH 投毒识别依赖硬编码 IP 段，且明确跳过 IPv6

- **位置**：`data/scrape/Http.kt:51-79`（`poisonRanges` 16 个硬编码 CIDR，注释标明是 2026-10-28 实测样本）、`:82-100`（`isPoisoned`，L84 `if (bytes.size != 4) return false`）、`:213-253`（`DohDns.lookup`）
- **风险**：GFW 注入池变化后硬编码段会漏判；IPv6 应答一律视为「干净」，若污染转向 AAAA 记录则识别失效。另外 `cache` 命中（L218-220）发生在熔断检查（L224）之前，熔断期内缓存恰好过期时仍会重试 DoH，与 L222 注释「熔断期内不再尝试 DoH」略有出入。
- **已核实正确**：CIDR 掩码计算逐位核对过（/16、/17、/20、/22 均正确），`ByteArray.toInt()` 的符号扩展在两侧一致比较下不影响结果，无实际计算错误。
- **最小修复**：段表改为可下发 / 可配置；IPv6 走同样的校验；把 `failureUntil` 检查提到 `cache` 之前，或缓存失效时同步刷新熔断状态。
- **验证方式**：为段内/段外 IPv4、边界 IP、IPv6 各补一条单测；模拟 DoH 全失败后检查 60 秒内是否真的不再发起 DoH 请求。

### RISK-12【中】屏保心跳在 Android 13+ 上实际不生效，只剩 `FLAG_KEEP_SCREEN_ON`

- **位置**：`ui/player/PlayerActivity.kt:116-153`（`startScreenGuard` / `pokeUserActivity` / `userActivityMethod` 反射）、`:47` 与 `:178`（`FLAG_KEEP_SCREEN_ON`）
- **风险**：`PowerManager.userActivity(long, boolean)` 自 API 33 起被废弃、compileSdk 36 已从 android.jar 移除，反射 `getMethod` 在新设备上返回 null，L141 直接 `return`，`runCatching { invoke }` 也兜不住「方法不存在」。注释 L135-138 说「目标机型是 Android 9」，但 `Models.kt` 与 build 配置并未把运行环境限制在 Android 9；在 Android 13+ 盒子上，L101-114 声称的「压制国产 ROM 屏保」这层兜底完全失效。
- **边界**：`repeatOnLifecycle(RESUMED)` 内 `while(true) { ...; delay(45s) }` 靠 lifecycle 取消退出，设计本身正确；`player.isPlaying` 是 Compose State，在主线程读，无线程问题。
- **最小修复**：明确设备兼容矩阵，API 33+ 改用可用的替代机制或接受降级并在注释中写明「仅 Android 9~12 生效」；补充实测：在 Android 13+ 盒子上静置超过系统屏保时间，观察是否被覆盖。
- **验证方式**：分别在 Android 9 与 Android 13+ 设备上播放并静置 > 屏保阈值，检查 `userActivityMethod` 是否为 null、屏幕是否被屏保盖住。

---

## 附：已核验为正确处理的设计（不作为问题上报）

避免复核时把这些当成遗漏，也说明本次审查的覆盖深度：

- `JsonStore.write()` 的 tmp + `fd.sync()` + `ATOMIC_MOVE` 顺序（L109-153）、空文件/反序列化失败的隔离与备份恢复流程（L44-58）、带时间戳的 `.corrupt` 留证（L100-107）—— 设计扎实，问题只出在 BUG-06 的「恢复回写」未复用它。
- `SecretBox.key()` 的 `@Synchronized`（L70）防止并发 `generateKey()` 覆盖密钥；`seal()` 的 `startsWith(PREFIX)` 幂等判断（L39）。
- `SmbPool` 的 `openHandles` / `activeOps` 双计数 + `retired` → `zombies` → `closeIfIdle` 退休机制（L297-309、L446-456），以及 `with()` 拿锁后二次检查 slot（L361-370）—— 并发考虑相当周全，缺口仅在 RISK-01 的 `closeAll()`。
- `LocalRepository.SaveGate` 的「取快照与领版本号同临界区」+ 写失败不推进 `written`（L577-596、L707-732），正确解决了并发刮削时旧快照覆盖新快照的问题；`scanMutex` / `scrapeMutex` / `settingsMutex` 的串行保护也到位。
- `SmbDataSource` 的 512KB 预读（L257-292）、`read()` 内就地重连而不把异常抛给 ExoPlayer（L196-243）、`transferring` 标志避免 `open()` 失败后 `close()` 误调 `transferEnded()`（L338-343）、以及 `SmbFile.read` 对 SMBJ 参数顺序的注释（SmbClient.kt L61-75）—— 都是踩过坑后的正确实现。
- `PlayerState.onVideoSizeChanged` 对 `NaN` / 0 / 越界宽高比的过滤（L884-896）确实能防住 `Modifier.aspectRatio` 抛异常导致的整页崩溃。
- `Scanner.walk` 跳过 `.` / `@` 前缀及元数据目录（L237-239）、`LocalRepository.scan` 的「启动自动扫描返回 0 条时保留旧库」（L316-333）—— 意图正确，缺口见 BUG-02 / RISK-05。

## 建议修复顺序

1. **P0（数据正确性 / 用户可感知）**：BUG-01、BUG-02、BUG-03、RISK-01、RISK-02
2. **P1（性能，改动收益比高）**：PERF-01（改用已存在的 OkHttp）、PERF-02（建索引）、PERF-03（缓存首页行）、BUG-07、BUG-08
3. **P2（健壮性与边界）**：BUG-05、BUG-06、BUG-10、RISK-03~RISK-10
4. **P3（清理 / 文档）**：BUG-12、BUG-04、BUG-09、BUG-11、PERF-07、PERF-08、RISK-11、RISK-12

## 复核清单（便于逐条验证）

- 构造 10 层嵌套目录 → 验证 BUG-02 / RISK-05 的 `failedDirs` 与旧库保留
- 播完电影按 OK 重播 → 验证 BUG-01 的进度条与 `playback.json`
- `./gradlew :app:dependencies | grep okhttp` → 验证 PERF-01 的依赖前提
- 抓包统计 1000 目录 WebDAV 扫描的 TCP 连接数 → 量化 PERF-01 / PERF-09
- 清除 AndroidKeyStore 条目后重启并保存服务器 → 验证 BUG-07 / RISK-04
- 播放无 duration 的 `.ts` 并退出 → 验证 BUG-08
- 扫描进行中触发 `closeAll()` → 验证 RISK-01
- 2000 条旧库重扫计时 → 量化 PERF-02 / PERF-03




